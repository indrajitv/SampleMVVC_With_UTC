//
//  Student.swift
//  SOLID
//
//  Created by Indrajit Chavda on 28/12/21.
//

import Foundation

struct Student {
    var name: String?
    var rollNumber: Int?
    var dob: Date?
}
